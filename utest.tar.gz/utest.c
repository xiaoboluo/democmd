/**************************************************************************************************/
/* Copyright (C) luoxiaobo, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  utest.c                                                              */
/*  PRINCIPAL AUTHOR      :  Luoxiaobo                                                            */
/*  SUBSYSTEM NAME        :  unittest                                                             */
/*  MODULE NAME           :  unittest                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a cmd unit test                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Luoxiaobo, 2014/09/21
 *
 */
#include<stdio.h>
#include"umenu.h"
#define debug printf
int results[3] = {1,1,1};
char * info[5] =
{
    "test report",
    "TC1 creat menu",
    "TC2.1  add cmd to menu",
    "TC2.2  add cmd to menu",
    "TC3 start menu"
};
int main()
{
    int i ;
/*test case for creat menu*/
    int retcm = CreatMenu();
    if(retcm == SUCCESS)
    {
        debug("TC1 succ\n");
        results[1] = 0;
    }
/*test case for add cmd to menu*/
    char* cmd = "help";
    char* desc = "this a help cmd";
    handler hd = NULL;
    int retacmd1 = AddCmdToMenu(cmd,desc,hd);
    if(retacmd1 == SUCCESS)
    {
        debug("TC2.1 add cmd succ\n");
        results[2] = 0;
    }
    else
    {
        debug("TC2.1 add cmd fail\n");
        results[2] = 1;
    }
    cmd = NULL;
    desc = NULL;
    hd = NULL;
    int retacmd2 = AddCmdToMenu(cmd,desc,hd);
    if(retacmd2 == SUCCESS)
    {
        debug("TC2.2 add cmd succ\n");
        results[3] = 0;
    }
    else
    {
        debug("TC2.2 add cmd fail\n");
        results[3] = 1;
    }
/*test case for start menu*/
    int retms = MenuStart();
/* more test case ...*/
/* test report */
    printf("test report\n");
    for(i=1;i<4;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
}
