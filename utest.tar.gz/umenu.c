/**************************************************************************************************/
/* Copyright (C) luoxiaobo, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  umenu.c                                                              */
/*  PRINCIPAL AUTHOR      :  Luoxiaobo                                                            */
/*  SUBSYSTEM NAME        :  umenu                                                                */
/*  MODULE NAME           :  umenu                                                                */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a unit menu                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Luoxiaobo, 2014/09/21
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "umenu.h"
/*function for logic*/
#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define BREAK_UP    -1

/*add a cmd to the list*/
int AddCmdToMenu(char* cmd,char* desc,handler hd)
{
    if(cmd == NULL || desc == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
int DeleteCmdFromMenu(char* cmd)
{   
    if(cmd == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
int ModifyCmdInMenu(char* cmd,char* desc,handler hd)
{
    if(cmd == NULL || desc == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}

int CreatMenu()
{
    return SUCCESS;
}


int MenuStart()
{
    system("echo 'help -this is a help cmd'");
}
