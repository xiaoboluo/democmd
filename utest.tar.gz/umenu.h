/**************************************************************************************************/
/* Copyright (C) luoxiaobo, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  umenu.c                                                              */
/*  PRINCIPAL AUTHOR      :  Luoxiaobo                                                            */
/*  SUBSYSTEM NAME        :  umenu                                                                */
/*  MODULE NAME           :  umenu                                                                */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a unit menu                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Luoxiaobo, 2014/09/21
 *
 */

#ifndef _UMENU_H_
#define _UMENU_H_
#define SUCCESS 0
#define FAILURE (-1)
typedef int(*handler)();
/*interface for the cmdmenu*/
/*creat menu */
int CreatMenu();

/*start menu and Init*/
int MenuStart();

/*add a cmd desc handler to the menu */
int AddCmdToMenu(char* cmd,char* desc,handler hd);

int DeleteCmdFromMenu(char* cmd);

int ModifyCmdInMenu(char* cmd,char* desc,handler hd);


#endif /* _UMENU_H_ */
