readme:
1 make
2 ./utest
即可看到无实际功能的test case。
