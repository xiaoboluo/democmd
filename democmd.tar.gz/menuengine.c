/**************************************************************************************************/
/* Copyright (C) luoxiaobo, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  menuengine.c                                                         */
/*  PRINCIPAL AUTHOR      :  Luoxiaobo                                                            */
/*  SUBSYSTEM NAME        :  menuengine                                                           */
/*  MODULE NAME           :  menuengine                                                           */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a cmd menu engine                                            */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Luoxiaobo, 2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "cmddemo.h"

#define  ENTERMENU  1
#define  ADDCMD     2
#define  DELETECMD  3
#define  MODIFYCMD  4
 
int modifyhandler();

int AddCmd()
{
	AddCmdToMenu("author","luoxiaobo ustc",NULL);
    printf("author info cmd added !!! \n");
    return 0 ;
}

int DeleteCmd()
{
    char deletecmd [100];
    scanf("%s",deletecmd);
    DeleteCmdFromMenu(deletecmd);
    printf("%s deleted from the menu \n",deletecmd);
}

int ModifyCmd()
{
    char modifycmd[100];
    printf("which Cmd You want to modify?\n");
    scanf("%s",modifycmd);
    tmenu* modifycmdmenu = (tmenu*)malloc(sizeof(tmenu));
    modifycmdmenu->desc = "this is modified desc";
    modifycmdmenu->cmd = modifycmd;
    modifycmdmenu->handler = modifyhandler;
    ModifyCmdInMenu(modifycmdmenu);
}


main( )
{ 
    MenuStart();
	while(1)
	{	
		int action = 0;
		printf("if you want to Enter The Cmd Menu , input 1\n");
        printf("if you want to Add Cmd To Menu , input 2\n");
        printf("if you want to Delete Cmd From Menu , input 3\n");
        printf("if you want to Modify Cmd From Menu , input 4\n");
		scanf("%d", &action);
		switch(action)
		{
			case ENTERMENU:
				EnterMenu();
				break;
			case ADDCMD:
				AddCmd();
				break;
            case DELETECMD:
                DeleteCmd();
                break;
            case MODIFYCMD:
                ModifyCmd();
                break;
			default:
                return;
				break;
		}
	}
}

int modifyhandler()
{
    printf("this is modifyhandler info !\n");
    return 0 ;
}
