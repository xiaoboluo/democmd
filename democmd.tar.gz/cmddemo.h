/**************************************************************************************************/
/* Copyright (C) luoxiaobo, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  cmddemo.h                                                            */
/*  PRINCIPAL AUTHOR      :  Luoxiaobo                                                            */
/*  SUBSYSTEM NAME        :  cmddemo                                                              */
/*  MODULE NAME           :  cmddemo                                                              */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a cmd menu engine                                            */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Luoxiaobo, 2014/09/21
 *
 */

#ifndef _CMD_MENU_H_
#define _CMD_MENU_H_
typedef int(*handler)();
typedef struct menu
{
    char*   cmd;
    char*   desc;
    int     (*handler)();
} tmenu;
/*interface for the cmdmenu*/
/*start menu and Init*/
int MenuStart();

/*Enter menu */
int EnterMenu();

/*add a cmd desc handler to the menu */
int AddCmdToMenu(char* cmd,char* desc,handler hd);
/**/
int DeleteCmdFromMenu(char* cmd);

int ModifyCmdInMenu(tmenu* menu);
#endif /* _CMD_MENU_H_ */
