/**************************************************************************************************/
/* Copyright (C) luoxiaobo, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  cmddemo.c                                                            */
/*  PRINCIPAL AUTHOR      :  Luoxiaobo                                                            */
/*  SUBSYSTEM NAME        :  cmddemo                                                              */
/*  MODULE NAME           :  cmddemo                                                              */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a cmd demo program                                           */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Luoxiaobo, 2014/09/21
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "linklist.h"
#include "cmddemo.h"
/*function for logic*/
int Help();
int Quit();
int Condition(tLinkTableNode * pNode);
#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define BREAK_UP    -1
typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
} tDataNode;

tLinkTable * head = NULL ; 
char* scmd = NULL;
/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;
}

/*add a cmd to the list*/
int AddCmdToMenu(char* cmd,char* desc,handler hd)
{
	if(cmd == NULL || desc == NULL)
	{
		printf("Input a valid command ");
		return 0;
	}
	AddNodeToList(head,cmd,desc,hd);
}
int DeleteCmdFromMenu(char* cmd)
{   
	if(cmd == NULL)
	{
		printf("Input a valid command ");
		return 0;
	}
    scmd = cmd ; 
    tLinkTableNode * sNode = SearchLinkTableNode(head, Condition);
    if(sNode == NULL)
    {
        return 0 ; 
    }
    DelLinkTableNode(head,sNode);
}
int ModifyCmdInMenu(tmenu* menu)
{
    if(menu == NULL)
    {
        return 0 ;
    }
    scmd = menu->cmd; 
    tLinkTableNode * sNode = SearchLinkTableNode(head, Condition);
    if(sNode == NULL)
    {
        printf("The Cmd You Want to Modify is not existed");
        return 0 ;
    }
    tDataNode * pnode = (tDataNode*)sNode;
    pnode->desc = menu->desc;
    pnode->handler = menu->handler;
    return 0;
}
/*add node to the list*/
int  AddNodeToList(tLinkTable * ppLinktable,char* cmd,char* desc,handler hd)
{
	tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = cmd;
    pNode->desc = desc;
    pNode->handler = hd;
	AddLinkTableNode(ppLinktable,(tLinkTableNode *)pNode);
    return 0 ;
}

int InitMenuData(tLinkTable ** ppLinktable)
{
    *ppLinktable = CreateLinkTable();
	AddNodeToList(*ppLinktable,"help","Menu List:",Help);
    AddNodeToList(*ppLinktable,"version","Menu Program V1.0",NULL);
	AddNodeToList(*ppLinktable,"quit","Quit from Menu Program V1.0",Quit);
    return 0; 
}

int MenuStart()
{
	InitMenuData(&head);
}

int EnterMenu()
{
   /* cmd line begins */
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a command > ");
        scanf("%s", cmd);
        tDataNode* p = FindCmd(head,cmd);
        if(p!=NULL)
        {
            printf("%s - %s\n", p->cmd, p->desc);
            if(p->handler != NULL)
            {
                if(p->handler() == BREAK_UP)
                {
                    break;
                }
            }
        }
        else
        {
            printf("This is a wrong cmd!\n ");
        }       
    }
}

int Help()
{    
    ShowAllCmd(head);
    return 0;
}
int Quit()
{
    return BREAK_UP;
}
int Condition(tLinkTableNode * pNode)
{
    tDataNode * tnode = (tDataNode*)pNode;
    if(!strcmp(scmd,tnode->cmd))
        return SUCCESS;
    else
        return FAILURE;
}
